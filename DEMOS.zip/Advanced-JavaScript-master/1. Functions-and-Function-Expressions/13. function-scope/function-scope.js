if (true) {
	//uncomment to create function scope
	//(function(){
	var result = 'From the if';
	//}());
}
console.log(result);
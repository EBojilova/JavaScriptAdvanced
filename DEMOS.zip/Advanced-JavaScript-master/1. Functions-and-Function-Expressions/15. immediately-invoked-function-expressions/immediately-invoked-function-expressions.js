(function () {
	console.log('Invoked')
}());
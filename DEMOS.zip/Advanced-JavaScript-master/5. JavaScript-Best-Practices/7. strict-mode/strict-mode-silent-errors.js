(function(){  
  'use strict';
  document = {};
}());
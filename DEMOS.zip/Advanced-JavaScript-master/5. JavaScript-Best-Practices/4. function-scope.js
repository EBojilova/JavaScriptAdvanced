(function(){
  if (false) {
    var count = 15;
    function printMsg(message) {
      console.log("Message: " + message + "!");
    };
  }  
}());

console.log(count);

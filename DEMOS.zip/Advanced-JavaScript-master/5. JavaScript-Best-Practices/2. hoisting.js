sum(2, 12);
var sum = function sum(x, y) {
	return x + y;
};

if (false) {
	function sayHello(message) {
		console.log(message);
	}
};

sayHello('Drasti!');
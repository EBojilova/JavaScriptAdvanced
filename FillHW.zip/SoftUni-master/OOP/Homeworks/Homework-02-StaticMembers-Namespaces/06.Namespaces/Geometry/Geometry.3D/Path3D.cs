﻿using System.Collections.Generic;

namespace Geometry.Geometry3D
{
    class Path3D
    {
        private List<Point3D> path;
    }
}

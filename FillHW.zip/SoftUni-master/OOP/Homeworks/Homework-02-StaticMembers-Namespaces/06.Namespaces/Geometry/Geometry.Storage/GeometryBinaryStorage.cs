﻿

namespace Geometry.Storage
{
    class GeometryBinaryStorage
    {
    }
}

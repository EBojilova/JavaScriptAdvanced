﻿

namespace Geometry.Storage
{
    class GeometryXMLStorage
    {
    }
}

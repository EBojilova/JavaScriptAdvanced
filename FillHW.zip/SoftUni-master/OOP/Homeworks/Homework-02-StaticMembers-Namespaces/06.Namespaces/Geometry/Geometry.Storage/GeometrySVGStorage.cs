﻿

namespace Geometry.Storage
{
    class GeometrySVGStorage
    {
    }
}

﻿

namespace Geometry.UI
{
    class Screen2D
    {
    }
}

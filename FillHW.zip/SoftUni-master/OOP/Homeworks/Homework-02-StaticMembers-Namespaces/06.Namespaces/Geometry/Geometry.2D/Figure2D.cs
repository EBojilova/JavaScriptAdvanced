﻿namespace Geometry.Geometry2D
{
    class Figure2D
    {
    }
}

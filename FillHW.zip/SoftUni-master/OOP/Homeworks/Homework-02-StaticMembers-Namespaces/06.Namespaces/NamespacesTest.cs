﻿
namespace Geometry
{
    using System;
    using Geometry2D;
    using Geometry3D;
    using Storage;
    using UI;

    class NamespacesTest
    {
        static void Main()
        {
            Console.WriteLine("Namepsaces...");
            Circle circle;
            Point3D point3D;
            GeometryXMLStorage storage;
            Screen2D screen;
        }
    }
}

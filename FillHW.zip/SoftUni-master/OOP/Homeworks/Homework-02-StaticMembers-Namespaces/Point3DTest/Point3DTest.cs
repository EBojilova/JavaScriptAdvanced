﻿namespace Point
{
    using System;

    class Point3DTest
    {
        static void Main()
        {
            Point3D point1 = new Point3D(1, 1, 1);
            Point3D point2 = new Point3D(2.5, -0.4, 12.09);
            Console.WriteLine(point1);
            Console.WriteLine(point2);
        }
    }
}


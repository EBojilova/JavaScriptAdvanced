﻿using System;

class JuniorTrainer : Trainer
{
    public JuniorTrainer(string firstName, string lastName, int age)
        : base(firstName, lastName, age)
    {
    }
}


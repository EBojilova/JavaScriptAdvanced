﻿namespace _01.Shapes.Contracts
{
    interface IShape
    {
        double CalculateArea();

        double CalculatePerimeter();
    }
}

﻿namespace _03.Animals.Contracts
{
    interface ISound
    {
        void ProduceSound();
    }
}

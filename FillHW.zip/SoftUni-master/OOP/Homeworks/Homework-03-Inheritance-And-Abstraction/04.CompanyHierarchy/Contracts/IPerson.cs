﻿namespace _04.CompanyHierarchy.Contracts
{
    interface IPerson
    {
        int Id { get; }

        string FirstName { get; }

        string LastName { get; }
    }
}

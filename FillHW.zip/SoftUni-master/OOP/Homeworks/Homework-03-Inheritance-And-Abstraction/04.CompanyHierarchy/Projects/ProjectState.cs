﻿namespace _04.CompanyHierarchy.Projects
{
    enum ProjectState
    {
        Open,
        Closed
    }
}

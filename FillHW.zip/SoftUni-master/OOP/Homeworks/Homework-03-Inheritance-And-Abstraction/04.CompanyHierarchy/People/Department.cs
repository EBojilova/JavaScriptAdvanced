﻿namespace _04.CompanyHierarchy.People
{
    enum Department
    {
        Production,
        Accounting,
        Sales,
        Marketing
    }
}

﻿namespace School.Contracts
{
    interface IDescribable
    {
        string Details { get; }
    }
}

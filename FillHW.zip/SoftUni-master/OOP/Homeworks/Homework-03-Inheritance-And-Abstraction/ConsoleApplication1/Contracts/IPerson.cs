﻿namespace School.Contracts
{
    interface IPerson : IDescribable
    {
        string Name { get; }
    }
}

﻿namespace Blobs.Contracts
{
    public interface IUpdateable
    {
        void Update();
    }
}

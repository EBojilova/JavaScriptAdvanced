﻿namespace Blobs.Contracts
{
    public interface IRunnable
    {
        void Run();
    }
}

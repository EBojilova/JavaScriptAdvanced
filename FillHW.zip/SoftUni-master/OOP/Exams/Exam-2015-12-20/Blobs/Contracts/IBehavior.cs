﻿namespace Blobs.Contracts
{
    public interface IBehavior : IUpdateable
    {
        void Activate();
    }
}

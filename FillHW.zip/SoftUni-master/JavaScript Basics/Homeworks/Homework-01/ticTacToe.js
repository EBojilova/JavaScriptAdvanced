var playerOne = true;



function click(square) {    
    
    if (playerOne) {
        
    }


}

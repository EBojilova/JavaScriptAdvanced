define([], function () {
    var containers = [];

    return containers;
});